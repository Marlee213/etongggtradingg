import { useState, useEffect } from "react";
import { Line } from "react-chartjs-2";
import { Chart as ChartJS, LineElement, PointElement, CategoryScale, LinearScale } from "chart.js";

ChartJS.register(LineElement, PointElement, CategoryScale, LinearScale);

export default function Home() {
  const [btcData, setBtcData] = useState([]);
  const [isAltseason, setIsAltseason] = useState(false);

  useEffect(() => {
    setTimeout(() => {
      setBtcData([30000, 30200, 29900, 30500, 30700]);
      setIsAltseason(true);
    }, 1000);
  }, []);

  return (
    <div style={{ padding: "2rem", fontFamily: "Arial, sans-serif" }}>
      <h1>EtongggTrading Live!</h1>
      <Line
        data={{
          labels: ["Mon", "Tue", "Wed", "Thu", "Fri"],
          datasets: [
            {
              label: "BTC Price",
              data: btcData,
              borderColor: "#f97316",
              fill: false,
            },
          ],
        }}
      />
      <p>
        {isAltseason
          ? "🔥 ALTSEASON ACTIVE — Great time to trade altcoins!"
          : "⛔ Bitcoin Dominance high — Altcoin season not yet confirmed."}
      </p>
      <p>
        Trade and earn with our affiliate:{" "}
        <a href="https://www.bybit.com/invite?ref=YXVD2R" target="_blank" rel="noopener noreferrer" style={{ color: "#3b82f6" }}>
          Join Bybit
        </a>
      </p>
    </div>
  );
}
